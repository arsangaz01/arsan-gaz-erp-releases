using System.Windows;
using ArsanGazERP.Services;
namespace ArsanGazERP;
public partial class MainWindow : Window
{
    private readonly AuthService _auth = new();
    private readonly GraphService _graph = new();
    private bool _connected;
    public MainWindow() => InitializeComponent();

    private async Task RunAsync(Func<Task<string>> action)
    {
        try { EnsureConnected(); Output.Text = await action(); }
        catch (Exception ex) { Output.Text = ex.ToString(); }
    }
    private void EnsureConnected() { if (!_connected) throw new InvalidOperationException("Önce Microsoft ile Giriş düğmesini kullanın."); }

    private async void Login_Click(object sender, RoutedEventArgs e)
    {
        try { var result = await _auth.SignInAsync(); _graph.SetToken(result.AccessToken); _connected = true; Output.Text = $"Bağlantı başarılı.\nHesap: {result.Account.Username}\nSüre sonu: {result.ExpiresOn.LocalDateTime}"; }
        catch (Exception ex) { Output.Text = ex.ToString(); }
    }
    private async void Profile_Click(object s, RoutedEventArgs e) => await RunAsync(_graph.GetProfileAsync);
    private async void OneDrive_Click(object s, RoutedEventArgs e) => await RunAsync(_graph.ListOneDriveFilesAsync);
    private async void Mail_Click(object s, RoutedEventArgs e) => await RunAsync(_graph.ListRecentMailAsync);
    private async void Contacts_Click(object s, RoutedEventArgs e) => await RunAsync(_graph.ListContactsAsync);
    private async void Calendar_Click(object s, RoutedEventArgs e) => await RunAsync(_graph.ListCalendarAsync);
    private async void Logout_Click(object s, RoutedEventArgs e) { await _auth.SignOutAsync(); _connected = false; Output.Text = "Microsoft oturumu kapatıldı."; }
}
