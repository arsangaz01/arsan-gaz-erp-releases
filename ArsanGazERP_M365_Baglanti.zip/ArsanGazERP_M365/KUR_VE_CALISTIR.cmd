@echo off
chcp 65001 >nul
where dotnet >nul 2>nul
if errorlevel 1 (
  echo .NET 8 SDK bulunamadi. Once .NET 8 SDK kurun.
  pause
  exit /b 1
)
dotnet restore
if errorlevel 1 pause & exit /b 1
dotnet run
if errorlevel 1 pause
