namespace ArsanGazERP.Models;
public static class AppSettings
{
    public const string ClientId = "3eaf1f8a-fbc8-40f0-9759-e134542606bf";
    public const string TenantId = "55b4c8c7-e0a8-46aa-953e-959f63fc7d91";
    public const string RedirectUri = "http://localhost";
    public static readonly string[] Scopes =
    [
        "User.Read", "Files.ReadWrite", "Mail.Read", "Mail.Send",
        "Contacts.Read", "Calendars.ReadWrite", "openid", "profile",
        "email", "offline_access"
    ];
}
