# Arsan Gaz ERP Microsoft 365 Bağlantısı

Bu paket .NET 8 WPF masaüstü uygulaması için Entra ID public-client bağlantısını içerir. İstemci gizli dizisi kullanılmaz.

## Hazır işlevler
- Microsoft hesabıyla etkileşimli giriş ve sessiz token yenileme
- Kullanıcı profili
- OneDrive kök dosya listesi
- Son 10 Outlook e-postası
- Outlook kişileri
- Takvim etkinlikleri
- Kod seviyesinde e-posta gönderme ve takvim etkinliği oluşturma

## Çalıştırma
1. Windows bilgisayarda .NET 8 SDK kurulu olmalıdır.
2. Klasörde `KUR_VE_CALISTIR.cmd` dosyasını çalıştırın.
3. Açılan uygulamada `Microsoft ile Giriş` düğmesini seçin.
4. Ardından Profil, OneDrive, Son E-postalar, Kişiler ve Takvim testlerini çalıştırın.

## Entra ayarları
- Uygulama istemci kimliği kodda tanımlıdır.
- Kiracı kimliği kodda tanımlıdır.
- Redirect URI: `http://localhost`
- Gerekli izinler: User.Read, Files.ReadWrite, Mail.Read, Mail.Send, Contacts.Read, Calendars.ReadWrite, openid, profile, email, offline_access.

## Güvenlik
- Client secret eklemeyin.
- Erişim tokenlarını dosyaya, günlüğe veya GitHub'a yazmayın.
- Üretim sürümüne geçerken kalıcı token önbelleği Windows DPAPI ile şifrelenmelidir.
