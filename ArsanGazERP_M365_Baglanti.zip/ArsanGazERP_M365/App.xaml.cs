using System.Windows;
namespace ArsanGazERP;
public partial class App : Application { }
