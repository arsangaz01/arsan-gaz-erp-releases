using Microsoft.Identity.Client;
using ArsanGazERP.Models;
namespace ArsanGazERP.Services;
public sealed class AuthService
{
    private readonly IPublicClientApplication _client = PublicClientApplicationBuilder
        .Create(AppSettings.ClientId)
        .WithTenantId(AppSettings.TenantId)
        .WithRedirectUri(AppSettings.RedirectUri)
        .Build();

    public async Task<AuthenticationResult> SignInAsync()
    {
        var accounts = await _client.GetAccountsAsync();
        try
        {
            return await _client.AcquireTokenSilent(AppSettings.Scopes, accounts.FirstOrDefault()).ExecuteAsync();
        }
        catch (MsalUiRequiredException)
        {
            return await _client.AcquireTokenInteractive(AppSettings.Scopes)
                .WithPrompt(Prompt.SelectAccount)
                .ExecuteAsync();
        }
    }

    public async Task SignOutAsync()
    {
        foreach (var account in await _client.GetAccountsAsync())
            await _client.RemoveAsync(account);
    }
}
