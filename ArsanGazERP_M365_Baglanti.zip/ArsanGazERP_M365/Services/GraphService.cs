using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
namespace ArsanGazERP.Services;
public sealed class GraphService
{
    private readonly HttpClient _http = new() { BaseAddress = new Uri("https://graph.microsoft.com/v1.0/") };
    public void SetToken(string token) => _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

    public async Task<string> GetProfileAsync() => await GetAsync("me?$select=displayName,mail,userPrincipalName");
    public async Task<string> ListOneDriveFilesAsync() => await GetAsync("me/drive/root/children?$select=id,name,size,lastModifiedDateTime,webUrl");
    public async Task<string> ListRecentMailAsync() => await GetAsync("me/messages?$top=10&$select=subject,from,receivedDateTime,isRead");
    public async Task<string> ListContactsAsync() => await GetAsync("me/contacts?$top=20&$select=displayName,emailAddresses,businessPhones");
    public async Task<string> ListCalendarAsync() => await GetAsync("me/events?$top=20&$orderby=start/dateTime&$select=subject,start,end,location");

    public async Task SendMailAsync(string to, string subject, string body)
    {
        var payload = new { message = new { subject, body = new { contentType = "Text", content = body }, toRecipients = new[] { new { emailAddress = new { address = to } } } }, saveToSentItems = true };
        await PostAsync("me/sendMail", payload);
    }

    public async Task CreateCalendarEventAsync(string subject, DateTime start, DateTime end)
    {
        var payload = new { subject, start = new { dateTime = start.ToString("yyyy-MM-ddTHH:mm:ss"), timeZone = "Turkey Standard Time" }, end = new { dateTime = end.ToString("yyyy-MM-ddTHH:mm:ss"), timeZone = "Turkey Standard Time" } };
        await PostAsync("me/events", payload);
    }

    private async Task<string> GetAsync(string path)
    {
        using var response = await _http.GetAsync(path);
        var text = await response.Content.ReadAsStringAsync();
        if (!response.IsSuccessStatusCode) throw new InvalidOperationException($"Graph hatası {(int)response.StatusCode}: {text}");
        return Pretty(text);
    }

    private async Task PostAsync(string path, object payload)
    {
        var json = JsonSerializer.Serialize(payload);
        using var response = await _http.PostAsync(path, new StringContent(json, Encoding.UTF8, "application/json"));
        var text = await response.Content.ReadAsStringAsync();
        if (!response.IsSuccessStatusCode) throw new InvalidOperationException($"Graph hatası {(int)response.StatusCode}: {text}");
    }

    private static string Pretty(string json)
    {
        using var doc = JsonDocument.Parse(json);
        return JsonSerializer.Serialize(doc, new JsonSerializerOptions { WriteIndented = true });
    }
}
