@echo off
chcp 65001 >nul
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o publish
if errorlevel 1 pause & exit /b 1
echo Yayin tamamlandi: publish\ArsanGazERP.exe
pause
