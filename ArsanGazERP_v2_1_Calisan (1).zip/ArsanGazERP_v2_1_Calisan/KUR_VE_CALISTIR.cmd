@echo off
chcp 65001 >nul
cd /d "%~dp0"
dotnet clean
dotnet restore
if errorlevel 1 pause & exit /b 1
dotnet run
if errorlevel 1 pause
