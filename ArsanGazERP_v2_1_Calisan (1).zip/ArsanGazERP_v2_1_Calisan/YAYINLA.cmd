@echo off
chcp 65001 >nul
cd /d "%~dp0"
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -o publish
if errorlevel 1 pause & exit /b 1
echo publish\ArsanGazERP.exe hazir.
pause
