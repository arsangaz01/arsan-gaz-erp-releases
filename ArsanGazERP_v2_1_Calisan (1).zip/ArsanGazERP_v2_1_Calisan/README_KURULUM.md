# Arsan Gaz ERP v2.1
Derleme hataları giderilmiş sürümdür. ZIP'i ayrı klasöre çıkarıp KUR_VE_CALISTIR.cmd dosyasını çalıştırın. Ajan, Excel yedekleme ve güncelleme kontrol altyapısı korunmuştur.